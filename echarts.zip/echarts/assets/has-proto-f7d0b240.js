var o={foo:{}},t=Object,_=function(){return{__proto__:o}.foo===o.foo&&!({__proto__:null}instanceof t)};export{_ as h};
