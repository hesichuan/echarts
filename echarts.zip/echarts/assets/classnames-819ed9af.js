import{g as c}from"./@babel-c19aaf6d.js";var a={exports:{}};/*!
	Copyright (c) 2018 Jed Watson.
	Licensed under the MIT License (MIT), see
	http://jedwatson.github.io/classnames
*/(function(i){(function(){var l={}.hasOwnProperty;function s(){for(var n=[],o=0;o<arguments.length;o++){var t=arguments[o];if(t){var e=typeof t;if(e==="string"||e==="number")n.push(t);else if(Array.isArray(t)){if(t.length){var f=s.apply(null,t);f&&n.push(f)}}else if(e==="object"){if(t.toString!==Object.prototype.toString&&!t.toString.toString().includes("[native code]")){n.push(t.toString());continue}for(var r in t)l.call(t,r)&&t[r]&&n.push(r)}}}return n.join(" ")}i.exports?(s.default=s,i.exports=s):window.classNames=s})()})(a);var p=a.exports;const v=c(p);export{v as k};
