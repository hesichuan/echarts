import{f as r}from"./function-bind-22e7ee79.js";var o=r,a=o.call(Function.call,Object.prototype.hasOwnProperty);export{a as s};
